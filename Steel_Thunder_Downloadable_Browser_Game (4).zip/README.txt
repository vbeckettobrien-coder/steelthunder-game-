# Steel Thunder browser-installable game (PWA)

## Publish it
1. Upload the **contents of the `site` folder** to your Netlify site (or another static host).
2. Make sure the site is served over HTTPS.
3. Visit the site on Android Chrome and use **Install app** / **Add to Home screen**.
4. On iPhone Safari, use **Share → Add to Home Screen**.

## Important limitations of this starter
- This adds the web app manifest, app icons, and a service worker cache for the app shell.
- The game still loads Three.js, PeerJS and fonts from external CDNs. The game therefore needs an internet connection for those dependencies; this is not full offline gameplay.
- The existing game code has no touch event handlers detected. Before promoting it as a mobile game, add and test touchscreen driving, aiming and firing controls on real phones.
- Peer-to-peer multiplayer depends on PeerJS signalling/connectivity and is not a managed production multiplayer service.
- This is a PWA website, not an App Store or Google Play listing.

## Netlify
Drag the `site` folder into Netlify Drop, or deploy it through your connected Git repository. Keep `index.html`, `manifest.webmanifest`, `sw.js`, and both icons at the published site root.
